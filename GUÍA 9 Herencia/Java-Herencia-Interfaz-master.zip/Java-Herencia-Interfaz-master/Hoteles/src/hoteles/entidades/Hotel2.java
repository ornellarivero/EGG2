package hoteles.entidades;

public class Hotel2 extends Hotel1 {

    protected boolean cajaSeguridad = true;

    public Hotel2(Double precio, Double superficie, Integer cantidadHabitaciones) {
        super(precio, superficie, cantidadHabitaciones);
    }
   
    
}
