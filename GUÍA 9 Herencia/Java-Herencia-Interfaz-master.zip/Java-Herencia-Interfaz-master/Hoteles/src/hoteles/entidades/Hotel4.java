package hoteles.entidades;

public class Hotel4 extends Hotel3 {

    protected boolean miniBarHabitacion = true;

    public Hotel4(Double precio, Double superficie, Integer cantidadHabitaciones) {
        super(precio, superficie, cantidadHabitaciones);
    }

}
