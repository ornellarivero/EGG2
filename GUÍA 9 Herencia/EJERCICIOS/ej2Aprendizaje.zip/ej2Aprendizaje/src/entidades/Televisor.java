package entidades;

public class Televisor extends Electrodomestico{
private float resolucion;
private boolean sintonizadorTDT;

    public Televisor() {
    }

    public Televisor(float resolucion, boolean sintonizadorTDT) {
        this.resolucion = resolucion;
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public Televisor(float resolucion, boolean sintonizadorTDT, int precio, String color, String consumoAF, double peso) {
        super(precio, color, consumoAF, peso);
        this.resolucion = resolucion;
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public float getResolucion() {
        return resolucion;
    }

    public void setResolucion(float resolucion) {
        this.resolucion = resolucion;
    }

    public boolean isSintonizadorTDT() {
        return sintonizadorTDT;
    }

    public void setSintonizadorTDT(boolean sintonizadorTDT) {
        this.sintonizadorTDT = sintonizadorTDT;
    }
}
