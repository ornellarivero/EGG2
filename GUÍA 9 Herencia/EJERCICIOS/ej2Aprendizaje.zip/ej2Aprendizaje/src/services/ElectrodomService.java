package services;

import entidades.Electrodomestico;
import java.util.Scanner;

public class ElectrodomService {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public String comprobarConsumoEnergetico() {
        System.out.print("Ingrese consumo A-F: ");
        String consumo = leer.next().toUpperCase();
        switch (consumo) {
            case "A":
            case "B":
            case "C":
            case "D":
            case "E":
            case "F":
                return consumo;
            default:
                return "F";
        }
    }

    public String comprobarColor() {
        System.out.print("Ingrese color.\n-BLANCO\n-NEGRO\n-ROJO\n-AZUL\n-GRIS");
        String color = leer.next().toUpperCase();
        switch (color) {
            case "BLANCO":
            case "NEGRO":
            case "ROJO":
            case "AZUL":
            case "GRIS":
                return color;
            default:
                return "BLANCO";
        }
    }

    public Electrodomestico crearElectr() {
        Electrodomestico e = new Electrodomestico();
        
        e.setColor(comprobarColor());
        e.setConsumoAF(comprobarConsumoEnergetico());

        System.out.print("Ingrese peso: ");
        e.setPeso(leer.nextFloat());

        return e;
    }
}
