package ej2aprendizaje;

public class Ej2Aprendizaje {

    public static void main(String[] args) {

    }

}
